import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-busca',
  templateUrl: './busca.page.html',
  styleUrls: ['./busca.page.scss'],
})
export class BuscaPage implements OnInit {
  public listaFavoritos = [];
  public escola = {};
  constructor() { }
  ngOnInit() {//preencher a tabela
    let table = document.getElementById('tabela');
    let linha = document.getElementById('linha');
    let lista: any = localStorage.getItem('lista');
    lista = JSON.parse(lista);
    let chave = [];
    let valor = [];
    if(lista.length === 0){
      const erro = document.getElementsByTagName('body')[1];
      erro.style.textAlign = 'center';
      erro.style.color ='red';
      erro.innerHTML = '<h1>Não foi possível encontrar nenhum match</h1>';
      erro.innerHTML += '<h2>Volte para a página inicial</h2>';
    }

    for (let i = 0; i<lista.length; i++) {
      chave = Object.keys(lista[i]);
      valor = Object.values(lista[i]);
      if(['nuAnoCenso', 'noEntidade', 'localizacao', 'noRegiao', 'sgUf', 'noMunicipio'].includes(chave[0])){
        if(!(i%10) && i !== 0){
          table.innerHTML += '<ion-row>'+'</ion-row>';
          table = document.getElementById('tabela');
        }
        linha.style.textAlign = 'center';
        linha.innerHTML += '<ion-col>' + valor[0] + '</ion-col>';
        linha = document.getElementById('linha');
      }
    }
  }
  favoritar() {
    const escolaString = localStorage.getItem('lista');
    const escola = JSON.parse(escolaString);
    let i =0 ;
    this.listaFavoritos = JSON.parse(localStorage.getItem('favorito'));
    if(this.listaFavoritos === null){
      this.listaFavoritos =[];
      this.listaFavoritos.push(escola);
      document.getElementById('favorito').replaceWith('Favorito');
    }
    else{
      document.getElementById('favorito').replaceWith('Favorito');
      this.listaFavoritos.forEach(e=>{
        if(e === escola){i++;}
        console.log(escola);
      });
      if(i===0){this.listaFavoritos.push(escola);}

    }
    /*Aqui deveria ser finalizado a lógica de salvar uma escola favorita e passar para a tabela dos favoritos em outra página*/
    localStorage.setItem('favorito',JSON.stringify(this.listaFavoritos));
}
}
