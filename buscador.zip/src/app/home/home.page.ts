import { ApiService } from './../services/api.service';
import { Component } from '@angular/core';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})

@Injectable()

export class HomePage {
  public codigo: number;
  public nome = '';
  public dadosEscola = [];
  constructor(private apiService: ApiService, private router: Router) {}

  buscarEscolas(){
    this.dadosEscola = [];
    this.apiService.buscarEscolas().subscribe(data => {
      const length1 = Object.keys(data).length;
      for(let i = 0; i<length1;i++){
        // eslint-disable-next-line max-len
        if((data[i].coEntidade === this.codigo) || (data[i].noEntidade === this.nome.toUpperCase())){// buscar por uma parte do nome|| (data[i].noEntidade.includes(this.nome.toUpperCase())) faria buscar mais de uma escola.
          const target = document.getElementById('result');
          const keys = Object.keys(data[i]);
          keys.forEach((chave,index)=>{
            if(data[i][chave] != null){
              this.dadosEscola.push({[chave] : data[i][chave]});
            }
          });
          if(data[i].coEntidade === this.codigo){
            i = length1;
          }
        }
      }
      localStorage.setItem('lista',JSON.stringify(this.dadosEscola));
      this.router.navigateByUrl('/busca');
    });
  }

}
