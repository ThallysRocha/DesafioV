import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private api = 'http://157.230.55.217/api/escolas';

  constructor(private http: HttpClient) { }

  buscarEscolas(){
    const listaDeEscolas = this.http.get(`${this.api}`);
    return listaDeEscolas;
  }
}
