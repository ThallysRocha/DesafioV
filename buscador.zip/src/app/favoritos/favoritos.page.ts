import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-favoritos',
  templateUrl: './favoritos.page.html',
  styleUrls: ['./favoritos.page.scss'],
})
export class FavoritosPage implements OnInit {
  public listaFavoritos = [];
  constructor() { }

  ngOnInit() {//preencher a tabela
    localStorage.setItem('favorito',JSON.stringify(this.listaFavoritos));
    const fav = JSON.stringify(localStorage.getItem('favorito'));

/*
    Aqui deveria ser implementado a função de escrever a tabela de favoritos.
*/
    let valores = [];
    localStorage.setItem('favoritos',JSON.stringify(this.listaFavoritos));
    this.listaFavoritos.forEach(e=>{
      e.forEach(element => {
        const keys = Object.keys(element);
        const valor = Object.values(element);
        if(['nuAnoCenso', 'noEntidade', 'localizacao', 'noRegiao', 'sgUf', 'noMunicipio'].includes(keys[0])){
          valores.push(valor[0]);

        }
      });
    });
    localStorage.setItem('favoValores',JSON.stringify(valores));
    console.log(valores);
  }

}
